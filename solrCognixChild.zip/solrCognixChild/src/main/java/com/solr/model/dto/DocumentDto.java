package com.solr.model.dto;

import java.util.Map;

import org.apache.solr.client.solrj.beans.Field;
import org.springframework.data.annotation.Id;
import org.springframework.data.solr.core.mapping.ChildDocument;
import org.springframework.data.solr.core.mapping.Dynamic;
import org.springframework.data.solr.core.mapping.Indexed;
import org.springframework.data.solr.core.mapping.SolrDocument;

@SolrDocument(collection = "DocumentDto")
public class DocumentDto {
	@Id
	@Indexed(name = "id", type = "string") 
	private String id;

	@Field("metadata")
	//@Indexed(name = "metadata", type = "string")
	@ChildDocument
	private ObaaDto metadata;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public ObaaDto getMetadata() {
		return metadata;
	}

	public void setMetadata(ObaaDto metadata) {
		this.metadata = metadata;
	}

    
    
}
