package com.solr.controller;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.solr.model.Document;
import com.solr.repository.DocumentRepository;
import com.solr.repository.ObaaDtoRepository;


@RestController
@RequestMapping("/document")
public class DocumentController {
	@Autowired
	DocumentRepository solrDocumentRepository;
	
	@PostMapping("")
	public ResponseEntity<Document> createDocument(@RequestBody Map<String, Object> document){
		try {
			Document documentModel = new Document();
			documentModel.setMetadata((Map<String, Object>) document.get("metadata"));
			solrDocumentRepository.save(documentModel);
			return new ResponseEntity<Document>(documentModel, HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("")
	public ResponseEntity<Document> updateDocument(@RequestBody Map<String, Object> document){
		try {
			Document documentModel = new Document();
			documentModel.setMetadata((Map<String, Object>) document.get("metadata"));
			solrDocumentRepository.save(documentModel);
			return new ResponseEntity<Document>(documentModel, HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/title")
	public ResponseEntity<List<Document>>  findDocumentByTitle(@RequestBody Map<String, Object> document){
		try {
			Map<String, Object> meta = (Map<String, Object>) document.get("metadata");
			List<Document> docs = solrDocumentRepository.findByAnnotatedNamedQuery(meta.get("title").toString());
			
			return new ResponseEntity<List<Document>>(docs, HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}

	} 
	
	@GetMapping("/all")
	public Iterable<Document> getAllDocument(){
		Iterable<Document> docs = solrDocumentRepository.findAll();
	    
		return docs;
	}
	
	@DeleteMapping("/{id}")
	public String deleteDocument(@PathVariable String id){
		try {
			solrDocumentRepository.delete(solrDocumentRepository.findById(id));
			String description = "Document Deleted";
			return description;
		}catch (Exception e) {
			return e.getLocalizedMessage();
		}
	}
	
	@DeleteMapping("/all")
	public String deleteAllDocument(){
		try {
			String description = "Document Deleted";
			solrDocumentRepository.deleteAll();
			return description;
		}catch (Exception e) {
			return e.getLocalizedMessage();
		}
	}
		
		
}
