package com.solr.controller;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.solr.model.dto.DocumentDto;
import com.solr.repository.DocumentDtoRepository;
import com.solr.repository.ObaaDtoRepository;


@RestController
@RequestMapping("/documentDto")
public class DocumentDtoController {
	@Autowired
	DocumentDtoRepository solrDocumentRepository;
	@Autowired
	ObaaDtoRepository solrObaaRepository;
	
	@PostMapping("")
	public String createDocument(@RequestBody Map<String, Object> documentDto){
		try {
			DocumentDto documentDtoModel = new DocumentDto();
			documentDtoModel.setMetadata((Map<String, Object>) documentDto.get("metadata"));
			solrDocumentRepository.save(documentDtoModel);
			String description = "Document Created";
			return description; 
		}catch (Exception e) {
			return e.getLocalizedMessage();
		}
		
		
	}
	
	@PostMapping("/title")
	public List<DocumentDto> findDocumentByTitle(@RequestBody Map<String, Object> documentDto){
		try {
			Map<String, Object> meta = (Map<String, Object>) documentDto.get("metadata");
		
			List<DocumentDto> docs = solrDocumentRepository.findByAnnotatedNamedQuery(meta.get("title").toString());
			
			return docs;
		}catch (Exception e) {
			return null;
		}

	} 
	@GetMapping("/all")
	public Iterable<DocumentDto> getAllDocument(){
		Iterable<DocumentDto> docs = solrDocumentRepository.findAll();
	    
		return docs;
	}
	
	@PutMapping("")
	public DocumentDto updateDocument(@RequestBody DocumentDto documentDto){
		try {
		
			solrDocumentRepository.save(documentDto);
			return documentDto;
		}catch (Exception e) {
			return null;
		}
	}
	
	@DeleteMapping("/{id}")
	public String deleteDocument(@PathVariable Long id){
		try {
			String description = "Document Deleted";
			solrDocumentRepository.delete(solrDocumentRepository.findById(id).get());
			return description;
		}catch (Exception e) {
			return e.getLocalizedMessage();
		}
	}
	
	@DeleteMapping("/all")
	public String deleteAllDocument(){
		String description = "Document Deleted";
		solrDocumentRepository.deleteAll();
		return description;
	}
		
		
}
