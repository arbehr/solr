package com.solr.controller;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.solr.model.dto.DocumentDto;
import com.solr.repository.DocumentDtoRepository;
import com.solr.repository.ObaaDtoRepository;


@RestController
@RequestMapping("/documentDto")
public class DocumentDtoController {
	@Autowired
	DocumentDtoRepository solrDocumentRepository;
	
	@PostMapping("")
	public ResponseEntity<DocumentDto> createDocument(@RequestBody Map<String, Object> documentDto){
		try {
			DocumentDto documentDtoModel = new DocumentDto();
			documentDtoModel.setMetadata((Map<String, Object>) documentDto.get("metadata"));
			solrDocumentRepository.save(documentDtoModel);
			return new ResponseEntity<DocumentDto>(documentDtoModel, HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("")
	public ResponseEntity<DocumentDto> updateDocument(@RequestBody Map<String, Object> documentDto){
		try {
			DocumentDto documentDtoModel = new DocumentDto();
			documentDtoModel.setMetadata((Map<String, Object>) documentDto.get("metadata"));
			solrDocumentRepository.save(documentDtoModel);
			return new ResponseEntity<DocumentDto>(documentDtoModel, HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/title")
	public ResponseEntity<List<DocumentDto>>  findDocumentByTitle(@RequestBody Map<String, Object> documentDto){
		try {
			Map<String, Object> meta = (Map<String, Object>) documentDto.get("metadata");
			List<DocumentDto> docs = solrDocumentRepository.findByAnnotatedNamedQuery(meta.get("title").toString());
			
			return new ResponseEntity<List<DocumentDto>>(docs, HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}

	} 
	
	@GetMapping("/all")
	public Iterable<DocumentDto> getAllDocument(){
		Iterable<DocumentDto> docs = solrDocumentRepository.findAll();
	    
		return docs;
	}
	
	@DeleteMapping("/{id}")
	public String deleteDocument(@PathVariable String id){
		try {
			solrDocumentRepository.delete(solrDocumentRepository.findById(id));
			String description = "Document Deleted";
			return description;
		}catch (Exception e) {
			return e.getLocalizedMessage();
		}
	}
	
	@DeleteMapping("/all")
	public String deleteAllDocument(){
		try {
			String description = "DocumentDto Deleted";
			solrDocumentRepository.deleteAll();
			return description;
		}catch (Exception e) {
			return e.getLocalizedMessage();
		}
	}
		
		
}
