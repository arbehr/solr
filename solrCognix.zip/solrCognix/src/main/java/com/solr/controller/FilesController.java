package com.solr.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.solr.model.Files;
import com.solr.repository.FilesRepository;



@RestController
@RequestMapping("/files")
public class FilesController {
	@Autowired
	FilesRepository solrfilesRepository;
	
	@PostMapping("")
	public ResponseEntity<Files> createFiles(@RequestBody Map<String, Object> files){
		try {
			Map<String, Object>  doc = (Map<String, Object>) files.get("document");
			Map<String, Object>  metadata = (Map<String, Object>) doc.get("metadata");
			
		//	System.out.println(doc.get("metadata"));
			Files filesModel = new Files();
			
		    Map<String, Object> document = new HashMap<String, Object>(); 
			for (Map.Entry<String, Object> entry : metadata.entrySet()) {
			     document.put("metadata_" + entry.getKey(), (String) entry.getValue());
			}	
			filesModel.setDocument(document);
			//System.out.println(filesModel);
			//System.out.println(document);
			solrfilesRepository.save(filesModel);
			return new ResponseEntity<Files>(filesModel, HttpStatus.OK);
		}catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("")
	public ResponseEntity<Files> updateFiles(@RequestBody Map<String, Object> files){
		try {
			Files filesModel = new Files();
			//filesModel.setDocument((Map<String, Object>) files.get("document"));
			solrfilesRepository.save(filesModel);
			return new ResponseEntity<Files>(filesModel, HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/title")
	public ResponseEntity<List<Files>>  findFilesByTitle(@RequestBody Map<String, Object> files){
		try {
			Map<String, Object>  doc = (Map<String, Object>) files.get("document");
			Map<String, Object>  metadata = (Map<String, Object>) doc.get("metadata");
			
			List<Files> docs = solrfilesRepository.findByAnnotatedNamedQuery(metadata.get("title").toString());
		
			return new ResponseEntity<List<Files>>(docs, HttpStatus.OK);
		}catch (Exception e) {
			e.getLocalizedMessage();
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	} 
	
	@GetMapping("/all")
	public Iterable<Files> getAllFiles(){
		Iterable<Files> docs = solrfilesRepository.findAll();
	    
		return docs;
	}
	
	@DeleteMapping("/{id}")
	public String deleteFiles(@PathVariable String id){
		try {
			solrfilesRepository.delete(solrfilesRepository.findById(id));
			String description = "Files Deleted";
			return description;
		}catch (Exception e) {
			return e.getLocalizedMessage();
		}
	}
	
	@DeleteMapping("/all")
	public String deleteAllFiles(){
		try {
			String description = "Files Deleted";
			solrfilesRepository.deleteAll();
			return description;
		}catch (Exception e) {
			return e.getLocalizedMessage();
		}
	}
		
		
}
