
package com.solr.model.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.solr.core.mapping.Indexed;
import org.springframework.data.solr.core.mapping.SolrDocument;

import com.solr.model.Document;

@SolrDocument(collection = "DocumentTinyDto")
public class DocumentTinyDto {
	@Id
	@Indexed(name = "id", type = "string")
    private String id;
	
	@Indexed(name = "title", type = "string") 
    private String title;

    public DocumentTinyDto(String id, String title) {
        this.id = id;
        this.title = title;
    }

    public DocumentTinyDto(Document d){
        this.id = d.getId();
        this.title = d.getMetadata().get("title").toString();
    }

    public String getId() {
        return id; 
    }

    public String getTitle() {
        return title;
    }

}
