package com.solr.repository;

import java.util.List;
import org.springframework.data.solr.repository.Query;
import org.springframework.data.solr.repository.SolrCrudRepository;
import com.solr.model.Files;


public interface FilesRepository extends SolrCrudRepository<Files, Long>  {
	
	@Query(name = "Files.findByDocument.findByMetadata.findByTitle")
	public List<Files> findByAnnotatedNamedQuery(String name);	
	public Files findById(String id);
}
