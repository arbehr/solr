package com.solr.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.solr.repository.Query;
import org.springframework.data.solr.repository.SolrCrudRepository;
import com.solr.model.dto.DocumentDto;

public interface DocumentDtoRepository extends SolrCrudRepository<DocumentDto, Long>  {
	
	public List<DocumentDto> findByMetadata(Map<String,Object> metadata);
	@Query(name = "DocumentDto.findByMetadata.findByTitle")
	List<DocumentDto> findByAnnotatedNamedQuery(String name);
}
