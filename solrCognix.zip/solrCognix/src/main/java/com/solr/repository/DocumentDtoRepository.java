package com.solr.repository;

import java.util.List;

import org.springframework.data.solr.repository.Query;
import org.springframework.data.solr.repository.SolrCrudRepository;
import com.solr.model.dto.DocumentDto;

public interface DocumentDtoRepository extends SolrCrudRepository<DocumentDto, Long>  {
	
	@Query(name = "DocumentDto.findByMetadata.findByTitle")
	public List<DocumentDto> findByAnnotatedNamedQuery(String name);
	
	public DocumentDto findById(String id);
	
	
}
