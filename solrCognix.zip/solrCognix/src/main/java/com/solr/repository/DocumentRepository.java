package com.solr.repository;

import java.util.List;
import java.util.Map;
import org.springframework.data.solr.repository.Query;
import org.springframework.data.solr.repository.SolrCrudRepository;
import com.solr.model.Document;


public interface DocumentRepository extends SolrCrudRepository<Document, Long>  {
	
	@Query(name = "Document.findByMetadata.findByTitle")
	public List<Document> findByAnnotatedNamedQuery(String name);
	
	public Document findById(String id);
}
