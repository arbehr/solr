package com.solr.controller;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.solr.model.dto.ObaaDto;
import com.solr.repository.ObaaDtoRepository;

@RestController
@RequestMapping("/obaa")
public class ObaaDtoController {
	@Autowired
	ObaaDtoRepository solrObaaRepository;
	
	@PostMapping("")
	public String createObaa(@RequestBody ObaaDto obaa){
		String description = "Obaa Created";
		solrObaaRepository.save(obaa);
		return description;
	}
	
	@GetMapping("/{obaaid}")
	public Optional<ObaaDto> findObaa(@PathVariable Long obaaid){
		return solrObaaRepository.findById(obaaid);
	} 
	
	@PutMapping("")
	public String updateObaa(@RequestBody ObaaDto obaa){
		String description = "Obaa Updated";
		solrObaaRepository.save(obaa);
		return description;
	}
	
	@DeleteMapping("/{obaaid}")
	public String deleteObaa(@PathVariable Long obaaId){
		String description = "Obaa Deleted";
		
		solrObaaRepository.delete(solrObaaRepository.findById(obaaId).get());
		return description;
	}
	
}
