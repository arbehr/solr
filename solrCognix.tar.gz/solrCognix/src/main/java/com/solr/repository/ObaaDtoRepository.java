package com.solr.repository;

import org.springframework.data.solr.repository.SolrCrudRepository;
import com.solr.model.dto.ObaaDto;

public interface ObaaDtoRepository extends SolrCrudRepository<ObaaDto, Long>  {

}
