package com.solr.repository;

import org.springframework.data.solr.repository.SolrCrudRepository;
import com.solr.model.dto.DocumentDto;

public interface DocumentDtoRepository extends SolrCrudRepository<DocumentDto, Long>  {

}
